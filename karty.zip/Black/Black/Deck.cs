﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Black
{
    public class Deck
    {
        private List<Card> cards;
        public List<Card> Cards
        {
            get
            {
                return cards;
            }
            set
            {
                cards = value;
            }
        }

        public Deck()
        {
            Cards = new List<Card>();
            ShuffleNewDeck();

        }

        public void ShuffleNewDeck()
        {
            cards.Clear();
            for (int i = 1; i < 5; i++)
            {
                for (int j = 0; j < 14; j++)
                {

                }
            }
        }
        public Card DrawCard(Hand hand)
        {
            Card drawn = cards[cards.Count - 1];
            cards.Remove(drawn);
            hand.Cards.Add(drawn);
            return drawn;
        }
    }
}