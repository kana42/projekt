﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Black
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private readonly int STARTING_HAND = 2;
        private readonly int MAX_CARDS_ON_TABLE = 11;
        PictureBox p;
        PictureBox q;
        Deck deck;
        Hand player;
        Hand computer;
        int computerSum;
        int playerSum;

        private void button1_Click(object sender, EventArgs e)//Hit
        {
            
        }

        private void button3_Click(object sender, EventArgs e)//nowa gra
        {

        }

        private void button2_Click(object sender, EventArgs e)//stay
        {

        }
    }
}
