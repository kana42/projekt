﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;

namespace Black
{
    public class Card
    {

        public enum CardValue
        {
            Ace = 1,
            Two = 2,
            Three = 3,
            Four = 4,
            Five = 5,
            Six = 6,
            Seven = 7,
            Eight = 8,
            Nine = 9,
            Ten = 10,
            Jack = 11,
            Queen = 12,
            King = 13
        }

        public enum CardSuit
        {
            Hearts = 1,
            Spades = 2,
            Clubs = 3,
            Diamonds = 4
        }

        Image image;
        CardValue cardvalue;
        CardSuit cardsuit;

        public Image Image
        {
            get
            {
                return image;
            }
        }
        public CardValue value
        {
            get
            {
                return cardvalue;
            }

            set
            {
                cardvalue = value;
                GetImage();
            }
        }

        public CardSuit Suit
        {
            get
            {
                return cardsuit;
            }

            set
            {
                cardsuit = value;
                GetImage();
            }
        }

        public Card()
        {
            cardvalue = 0;
            cardsuit = 0;
            image = null;
        }

        private void GetImage()
        {
            if (Suit != 0 && value != 0)
            {
                int x = 0;
                int y = 0;
                int height = 97;
                int width = 73;

                switch (Suit)
                {
                    case CardSuit.Hearts:
                        y = 196;
                        break;
                    case CardSuit.Spades:
                        y = 98;
                        break;
                    case CardSuit.Clubs:
                        y = 0;
                        break;
                    case Card.CardSuit.Diamonds:
                        y = 294;
                        break;
                }
                x = width * ((int)this.value - 1);

                DirectoryInfo dir = new DirectoryInfo(@"D:\STUDIA\Informatyka\Semestr_IV\programowanie\Kol");

                Bitmap source = (Bitmap) Image.FromFile(dir.Parent + "\\karty.png");
                Bitmap img = new Bitmap(width, height);
                Graphics g = Graphics.FromImage(img);
                g.DrawImage(source, new Rectangle(0, 0, width, height), new Rectangle(x, y, width, height), GraphicsUnit.Pixel);
                g.Dispose();
                image = img;
            }
        }

    }
}
