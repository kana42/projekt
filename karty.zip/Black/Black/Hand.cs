﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Black
{
    public class Hand
    {
        private List<Card> cards;

        public List<Card> Cards
        {
            get { return cards; }
        }

        public Hand(int startingHand, Deck deck)
        {
            if (deck == null) throw new DeckException("No decks available to draw from!");
            else if (deck.Cards.Count == 0) throw new DeckException("No more cards to draw!");
            else
            {
                cards = new List<Card>();
                for (int i = 0; i < startingHand; i++)
                {
                    deck.DrawCard(this);
                }
            }
        }

        public void AddValue(Card drawn, ref int currentSum)
        {
            if (drawn.value == Card.CardValue.Ace)
            {
                if (currentSum <= 10)
                {
                    currentSum += 11;
                }
                else
                {
                    currentSum += 1;
                }
            }
            else if (drawn.value == Card.CardValue.Jack || drawn.value == Card.CardValue.Queen || drawn.value == Card.CardValue.King)
            {
                currentSum += 10;
            }
            else
            {
                currentSum += (int)drawn.value;
            }
        }
    }
}