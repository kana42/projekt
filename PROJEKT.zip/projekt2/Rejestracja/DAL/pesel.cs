﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    public class Pesel
    {
        

        public string pesel { get; set; }
        
        


        public override string ToString()
        {
            return $" {pesel}";
        }

        public Pesel(MySqlDataReader reader)
        {

            pesel = (string)reader["pesel"];

           
        }
    }
}

