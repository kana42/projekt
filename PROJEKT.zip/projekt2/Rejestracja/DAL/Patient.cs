﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    public class Patient
    {
        public string ID { get; set; }

        public string FirstNameP { get; set; }
        public string LastNameP { get; set; }

        public string Pesel { get; set; }
        public static Patient[] ListPacjenci { get; internal set; }

        public override string ToString()
        {
            return $"{ID} {FirstNameP} {LastNameP}";
        }

        public Patient(MySqlDataReader reader)
        {
            ID = (string)reader["pesel"];
            FirstNameP = (string)reader["imie"];
            LastNameP = (string)reader["nazwisko"];
        }

    }
}

