﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Rejestracja.DAL;

namespace Rejestracja
{
    public partial class Okno2 : Form
    {
        private Doctor doctor;
        public Okno2(Doctor doktor)
        {
            this.doctor = doktor;
            InitializeComponent();
        }

        private void Okno2_Load(object sender, EventArgs e)
        {
            textBox1.Text = doctor.FirstName + " " + doctor.LastName;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
