﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace Rejestracja.DAL
{
    class Visit
    {
         public byte ID{ get; set; }

        public string Pesel { get; set; }
        public  string Data { get; set; }
        public string Godzina { get; set; }


        public override string ToString()
        {
            return $"{ID} {Pesel} {Data} {Godzina}";
        }

        public Visit(MySqlDataReader reader)
        {
            ID = (byte)reader["id_w"];
            Pesel = (string)reader["pesel"];
            Data= (string)reader["data"];
            Godzina = (string)reader["godzina"];
        }
    }
}
