﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using Rejestracja.DAL;

namespace Rejestracja
{
    using DAL;
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void rejestracja1_Load(object sender, EventArgs e)
        {
            var doc = DoctorsRepository.GetAllDoctors();
            var wiz = VisitRepository.GetAllVisit();


            foreach (var d in doc)
                Console.WriteLine(d);
            rejestracja1.ListLekarzy = doc.ToArray();

            foreach (var w in wiz)
                Console.WriteLine(w);
           rejestracja1.ListWizyty = wiz.ToArray();

        }
    }
}
