﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace formularz
{
    class User
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthdayDate;
        public int Age
        {
            get
            {
                TimeSpan ts = DateTime.Now - BirthdayDate;
                int age = (int)ts.TotalDays / 365;
                return age;
            }
        }
        public User(string firstname, string lastname, DateTime birthdaydate)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.BirthdayDate = birthdaydate;
          
            
        }
        public override string ToString()
        {
            return $"{FirstName} {LastName} lat {Age}";
        }
    }
}
