﻿namespace formularz
{
    partial class Formularz
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Lista = new System.Windows.Forms.ListBox();
            this.logowanie = new System.Windows.Forms.GroupBox();
            this.zapisz = new System.Windows.Forms.Button();
            this.data = new System.Windows.Forms.DateTimePicker();
            this.usun = new System.Windows.Forms.Button();
            this.edytuj = new System.Windows.Forms.Button();
            this.dodaj = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nazwisko = new System.Windows.Forms.TextBox();
            this.imie = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.import = new System.Windows.Forms.Button();
            this.logowanie.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // Lista
            // 
            this.Lista.FormattingEnabled = true;
            this.Lista.Location = new System.Drawing.Point(281, 17);
            this.Lista.Name = "Lista";
            this.Lista.Size = new System.Drawing.Size(279, 316);
            this.Lista.TabIndex = 0;
            this.Lista.SelectedIndexChanged += new System.EventHandler(this.Lista_SelectedIndexChanged);
            // 
            // logowanie
            // 
            this.logowanie.Controls.Add(this.import);
            this.logowanie.Controls.Add(this.zapisz);
            this.logowanie.Controls.Add(this.data);
            this.logowanie.Controls.Add(this.usun);
            this.logowanie.Controls.Add(this.edytuj);
            this.logowanie.Controls.Add(this.dodaj);
            this.logowanie.Controls.Add(this.label3);
            this.logowanie.Controls.Add(this.label2);
            this.logowanie.Controls.Add(this.label1);
            this.logowanie.Controls.Add(this.nazwisko);
            this.logowanie.Controls.Add(this.imie);
            this.logowanie.Location = new System.Drawing.Point(8, 17);
            this.logowanie.Name = "logowanie";
            this.logowanie.Size = new System.Drawing.Size(267, 330);
            this.logowanie.TabIndex = 1;
            this.logowanie.TabStop = false;
            this.logowanie.Text = "logowanie";
            // 
            // zapisz
            // 
            this.zapisz.Location = new System.Drawing.Point(118, 243);
            this.zapisz.Name = "zapisz";
            this.zapisz.Size = new System.Drawing.Size(79, 30);
            this.zapisz.TabIndex = 10;
            this.zapisz.Text = "Zapisz";
            this.zapisz.UseVisualStyleBackColor = true;
            this.zapisz.Click += new System.EventHandler(this.zapisz_Click);
            // 
            // data
            // 
            this.data.Location = new System.Drawing.Point(18, 136);
            this.data.Name = "data";
            this.data.Size = new System.Drawing.Size(201, 20);
            this.data.TabIndex = 9;
            this.data.ValueChanged += new System.EventHandler(this.data_ValueChanged);
            // 
            // usun
            // 
            this.usun.Location = new System.Drawing.Point(117, 194);
            this.usun.Name = "usun";
            this.usun.Size = new System.Drawing.Size(80, 27);
            this.usun.TabIndex = 8;
            this.usun.Text = "Usuń";
            this.usun.UseVisualStyleBackColor = true;
            this.usun.Click += new System.EventHandler(this.usun_Click);
            // 
            // edytuj
            // 
            this.edytuj.Location = new System.Drawing.Point(8, 243);
            this.edytuj.Name = "edytuj";
            this.edytuj.Size = new System.Drawing.Size(81, 31);
            this.edytuj.TabIndex = 7;
            this.edytuj.Text = "Edytuj";
            this.edytuj.UseVisualStyleBackColor = true;
            this.edytuj.Click += new System.EventHandler(this.edytuj_Click);
            // 
            // dodaj
            // 
            this.dodaj.Location = new System.Drawing.Point(11, 194);
            this.dodaj.Name = "dodaj";
            this.dodaj.Size = new System.Drawing.Size(79, 27);
            this.dodaj.TabIndex = 6;
            this.dodaj.Text = "Dodaj";
            this.dodaj.UseVisualStyleBackColor = true;
            this.dodaj.Click += new System.EventHandler(this.dodaj_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Data Urodzenia";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nazwisko";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Imie";
            // 
            // nazwisko
            // 
            this.nazwisko.Location = new System.Drawing.Point(117, 72);
            this.nazwisko.Name = "nazwisko";
            this.nazwisko.Size = new System.Drawing.Size(114, 20);
            this.nazwisko.TabIndex = 1;
            // 
            // imie
            // 
            this.imie.Location = new System.Drawing.Point(117, 32);
            this.imie.Name = "imie";
            this.imie.Size = new System.Drawing.Size(115, 20);
            this.imie.TabIndex = 0;
            this.imie.TextChanged += new System.EventHandler(this.firstname_TextChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // import
            // 
            this.import.Location = new System.Drawing.Point(8, 290);
            this.import.Name = "import";
            this.import.Size = new System.Drawing.Size(81, 34);
            this.import.TabIndex = 11;
            this.import.Text = "Importuj dane";
            this.import.UseVisualStyleBackColor = true;
            this.import.Click += new System.EventHandler(this.import_Click);
            // 
            // Formularz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 370);
            this.Controls.Add(this.logowanie);
            this.Controls.Add(this.Lista);
            this.Name = "Formularz";
            this.Text = "Formularz";
            this.logowanie.ResumeLayout(false);
            this.logowanie.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox Lista;
        private System.Windows.Forms.GroupBox logowanie;
        private System.Windows.Forms.Button usun;
        private System.Windows.Forms.Button edytuj;
        private System.Windows.Forms.Button dodaj;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nazwisko;
        private System.Windows.Forms.TextBox imie;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.DateTimePicker data;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.Button zapisz;
        private System.Windows.Forms.Button import;
    }
}

