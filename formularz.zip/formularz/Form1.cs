﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace formularz
{
    public partial class Formularz : Form
    {
        public Formularz()
        {
            InitializeComponent();
            imie.Select();
        }
       
        private void firstname_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dodaj_Click(object sender, EventArgs e)
        {

            
                if (imie.Text == "" || nazwisko.Text == "")
                {
                if(imie.Text=="")
                    errorProvider1.SetError(imie, "Puste Pole");
                if(nazwisko.Text == "")
                    errorProvider1.SetError(nazwisko, "Puste Pole");
                MessageBox.Show("Brak danych!");
                }
               
               
            
            else
            {
               
                
                errorProvider1.SetError(imie, "");
                errorProvider1.SetError(nazwisko, "");
                Lista.Items.Add(new User(imie.Text, nazwisko.Text, Convert.ToDateTime(data.Text)));
                imie.Clear();
                nazwisko.Clear();
                data.ResetText();
            }
           

        }

        private void edytuj_Click(object sender, EventArgs e)
            
        {

           
            if (Lista.SelectedItem !=null)
            { 
                if (imie.Text == "" || nazwisko.Text == "")
                {
                    if (imie.Text == "")
                        errorProvider1.SetError(imie, "Puste Pole");
                    if (nazwisko.Text == "")
                        errorProvider1.SetError(nazwisko, "Puste Pole");
                    MessageBox.Show("Brak danych!");
                }
                else
                {
                    User a = Lista.Items[Lista.SelectedIndex] as User;
                    a.FirstName = imie.Text;
                    a.LastName = nazwisko.Text;
                    a.BirthdayDate = Convert.ToDateTime(data.Text);

                    Lista.Items[Lista.SelectedIndex] = a;
                    imie.Clear();
                    nazwisko.Clear();
                    data.ResetText();
                }
            }
            else
                MessageBox.Show("Nic nie zaznaczono!");






        }

        private void Lista_SelectedIndexChanged(object sender, EventArgs e)
        {
            User u = Lista.SelectedItem as User;
            if(u !=null)
            {
                imie.Text = u.FirstName;
                nazwisko.Text = u.LastName;
                data.Text = Convert.ToString(u.BirthdayDate);
                
            }
            //if (Lista.SelectedIndex > -1)
            //{

            //    string record = Lista.Items[Lista.SelectedIndex].ToString();
            //    char[] delim = { ' ' };
            //    string[] tokens = record.Split(delim);
            //    imie.Text = Convert.ToString(tokens[0]);
            //    nazwisko.Text = Convert.ToString(tokens[1]);
            //    int data = 2019 - Convert.ToInt32(tokens[3]);
            //    Lista.SelectedItem = (new User(imie.Text, nazwisko.Text, new DateTime (data,01,01)));




            //}

        }

        private void usun_Click(object sender, EventArgs e)
        {
            if (Lista.SelectedItem != null)
            {
                Lista.Items.RemoveAt(Lista.SelectedIndex);
                imie.Clear();
                nazwisko.Clear();
                data.ResetText();
            }
            else
            {
                MessageBox.Show("Nic nie zaznaczono!");
            }

        }

        private void data_ValueChanged(object sender, EventArgs e)
        {
            if(Convert.ToDateTime(data.Text)>DateTime.Now)
            {
                errorProvider2.SetError(data, "Podano nieprawdidłową datę !");
                MessageBox.Show("Błędna data !");
            }
            else
                errorProvider2.SetError(data, "");
        }

        private void zapisz_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            if(dlg.ShowDialog()==DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(dlg.FileName);
                for (int i=0; i<Lista.Items.Count; i++)
                {
                    writer.WriteLine(Convert.ToString(Lista.Items[i]));
                }
                writer.Close();
            }

            dlg.Dispose();
            Lista.Items.Clear();


            
            MessageBox.Show("Dane zapisane!");
        }

        private void import_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string[] lines = System.IO.File.ReadAllLines(ofd.FileName);
                List<int> list = new List<int>();
                foreach (string line in lines)
                {
                    Lista.Items.Add(line);
                    Convert.ToString(Lista.Items);
                    
                }

                
                


                ofd.Dispose();

            }
        }
    }
}
